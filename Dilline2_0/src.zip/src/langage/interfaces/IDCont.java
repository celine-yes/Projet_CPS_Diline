package langage.interfaces;

public interface IDCont extends ICont{
	public IDirs getDirs();
	public int getMaxSauts();
}
