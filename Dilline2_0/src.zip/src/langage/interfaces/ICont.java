package langage.interfaces;

public interface ICont extends IEvaluable{

}
