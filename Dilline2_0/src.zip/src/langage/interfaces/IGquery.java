package langage.interfaces;

public interface IGquery extends QueryI{
	public IGather getGather();
}
