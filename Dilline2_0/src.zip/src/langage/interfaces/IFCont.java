package langage.interfaces;

public interface IFCont extends ICont{
	public IBase getBase();
	public double getMaxDist();
}
