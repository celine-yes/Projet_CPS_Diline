package langage.interfaces;

public interface IRand extends IEvaluable{
	
}
