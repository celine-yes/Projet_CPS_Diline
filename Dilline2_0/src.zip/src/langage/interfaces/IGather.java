package langage.interfaces;

public interface IGather extends IEvaluable{
	public String getSensorId();
}
