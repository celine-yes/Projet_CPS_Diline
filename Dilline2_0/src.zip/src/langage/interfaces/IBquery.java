package langage.interfaces;

public interface IBquery extends QueryI{
	public IBexp getBexp();
	public ICont getCont();
	
}

