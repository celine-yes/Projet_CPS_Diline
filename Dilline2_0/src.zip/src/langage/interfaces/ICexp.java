package langage.interfaces;

public interface ICexp extends IBexp{
	public IRand getRand1();
	public IRand getRand2();
}
