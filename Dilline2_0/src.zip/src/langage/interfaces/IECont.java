package langage.interfaces;

public interface IECont extends ICont{

}
