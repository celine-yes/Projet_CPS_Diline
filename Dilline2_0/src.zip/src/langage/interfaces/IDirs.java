package langage.interfaces;

import fr.sorbonne_u.cps.sensor_network.interfaces.Direction;

public interface IDirs extends IEvaluable{
	public Direction getDir();
}
